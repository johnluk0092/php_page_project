<?php
require('include/header.php');
require('include/sidebar.php');
?>
<body>
	<a>THIS IS HOME PAGE</a>
</body>
<!-- Main Content End -->

<?php
require('include/footer.php');
require('include/script.php');
?>