<?php
require('includes/header.php');
require('../db/conn.php');

$id = $_GET['id'] ?? 0;
$error = '';
$success = '';

// Fetch order data
$stmt = $conn->prepare("SELECT * FROM orders WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order) {
    die("Order not found");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order = [
        'id' => $id,
        'user_id' => $_POST['user_id'] ? (int)$_POST['user_id'] : null,
        'firstname' => trim($_POST['firstname']),
        'lastname' => trim($_POST['lastname']),
        'address' => trim($_POST['address']),
        'phone' => trim($_POST['phone']),
        'email' => trim($_POST['email']),
        'status' => trim($_POST['status'])
    ];
    
    if (empty($order['firstname']) || empty($order['lastname']) || empty($order['phone']) || empty($order['email']) || empty($order['address'])) {
        $error = 'All fields except user ID are required';
    } elseif (!filter_var($order['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format';
    } elseif (strlen($order['firstname']) > 50 || strlen($order['lastname']) > 50) {
        $error = 'First name and last name must be 50 characters or less';
    } elseif (strlen($order['email']) > 50) {
        $error = 'Email must be 50 characters or less';
    } elseif (strlen($order['phone']) > 20) {
        $error = 'Phone must be 20 characters or less';
    } else {
        $update = $conn->prepare("UPDATE orders SET 
            user_id = ?, firstname = ?, lastname = ?, address = ?, 
            phone = ?, email = ?, status = ?, updated_at = NOW() 
            WHERE id = ?");
        $update->bind_param("issssssi", 
            $order['user_id'], $order['firstname'], $order['lastname'], 
            $order['address'], $order['phone'], $order['email'], 
            $order['status'], $order['id']);
        
        if ($update->execute()) {
            $success = 'Order updated successfully!';
            // Refresh order data
            $order = $conn->query("SELECT * FROM orders WHERE id = $id")->fetch_assoc();
        } else {
            $error = 'Error updating order: ' . $conn->error;
        }
    }
}
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <h2 class="mb-4">Edit Order</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="firstname">First Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="firstname" name="firstname" 
                               value="<?= htmlspecialchars($order['firstname']) ?>" maxlength="50" required>
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="lastname">Last Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="lastname" name="lastname" 
                               value="<?= htmlspecialchars($order['lastname']) ?>" maxlength="50" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="email">Email <span class="text-danger">*</span></label>
                    <input type="email" class="form-control" id="email" name="email" 
                           value="<?= htmlspecialchars($order['email']) ?>" maxlength="50" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="phone" name="phone" 
                           value="<?= htmlspecialchars($order['phone']) ?>" maxlength="20" required>
                </div>
                
                <div class="form-group">
                    <label for="address">Address <span class="text-danger">*</span></label>
                    <textarea class="form-control" id="address" name="address" required><?= htmlspecialchars($order['address']) ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="status">Status</label>
                    <select class="form-control" id="status" name="status">
                        <option value="Processing" <?= $order['status'] == 'Processing' ? 'selected' : '' ?>>Processing</option>
                        <option value="Confirmed" <?= $order['status'] == 'Confirmed' ? 'selected' : '' ?>>Confirmed</option>
                        <option value="Shipping" <?= $order['status'] == 'Shipping' ? 'selected' : '' ?>>Shipping</option>
                        <option value="Delivered" <?= $order['status'] == 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                        <option value="Cancelled" <?= $order['status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary">Update Order</button>
                <a href="addorder.php" class="btn btn-secondary">Back to List</a>
            </form>
        </div>
    </div>
</div>
<?php
require('includes/footer.php');
?>