<?php
require('includes/header.php');
require('../db/conn.php');

// Initialize variables
$order = [
    'user_id' => '',
    'firstname' => '',
    'lastname' => '',
    'address' => '',
    'phone' => '',
    'email' => '',
    'status' => 'Processing'
];
$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $order = [
        'user_id' => $_POST['user_id'] ? (int)$_POST['user_id'] : null,
        'firstname' => trim($_POST['firstname']),
        'lastname' => trim($_POST['lastname']),
        'address' => trim($_POST['address']),
        'phone' => trim($_POST['phone']),
        'email' => trim($_POST['email']),
        'status' => trim($_POST['status'])
    ];
    
    // Validate inputs
    if (empty($order['firstname']) || empty($order['lastname']) || empty($order['phone']) || empty($order['email']) || empty($order['address'])) {
        $error = 'All fields except user ID are required';
    } elseif (!filter_var($order['email'], FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format';
    } elseif (strlen($order['firstname']) > 50 || strlen($order['lastname']) > 50) {
        $error = 'First name and last name must be 50 characters or less';
    } elseif (strlen($order['email']) > 50) {
        $error = 'Email must be 50 characters or less';
    } elseif (strlen($order['phone']) > 20) {
        $error = 'Phone must be 20 characters or less';
    } else {
        // Insert new order
        $stmt = $conn->prepare("INSERT INTO orders 
            (user_id, firstname, lastname, address, phone, email, status, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
        $stmt->bind_param("issssss", 
            $order['user_id'], $order['firstname'], $order['lastname'], 
            $order['address'], $order['phone'], $order['email'], $order['status']);
        
        if ($stmt->execute()) {
            $success = 'Order added successfully!';
            // Clear form
            $order = [
                'user_id' => '',
                'firstname' => '',
                'lastname' => '',
                'address' => '',
                'phone' => '',
                'email' => '',
                'status' => 'Processing'
            ];
        } else {
            $error = 'Error adding order: ' . $conn->error;
        }
    }
}

// Get all orders with user information if available
$orders = $conn->query("
    SELECT o.*, u.name as user_name 
    FROM orders o
    LEFT JOIN users u ON o.user_id = u.id
    ORDER BY o.created_at DESC
")->fetch_all(MYSQLI_ASSOC);
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-12">
            <h2 class="mb-4">Add New Order</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="firstname">First Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="firstname" name="firstname" 
                               value="<?= htmlspecialchars($order['firstname']) ?>" maxlength="50" required>
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="lastname">Last Name <span class="text-danger">*</span></label>
                        <input type="text" class="form-control" id="lastname" name="lastname" 
                               value="<?= htmlspecialchars($order['lastname']) ?>" maxlength="50" required>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="email">Email <span class="text-danger">*</span></label>
                    <input type="email" class="form-control" id="email" name="email" 
                           value="<?= htmlspecialchars($order['email']) ?>" maxlength="50" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" id="phone" name="phone" 
                           value="<?= htmlspecialchars($order['phone']) ?>" maxlength="20" required>
                </div>
                
                <div class="form-group">
                    <label for="address">Address <span class="text-danger">*</span></label>
                    <textarea class="form-control" id="address" name="address" required><?= htmlspecialchars($order['address']) ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="status">Status</label>
                    <select class="form-control" id="status" name="status">
                        <option value="Processing" <?= $order['status'] == 'Processing' ? 'selected' : '' ?>>Processing</option>
                        <option value="Confirmed" <?= $order['status'] == 'Confirmed' ? 'selected' : '' ?>>Confirmed</option>
                        <option value="Shipping" <?= $order['status'] == 'Shipping' ? 'selected' : '' ?>>Shipping</option>
                        <option value="Delivered" <?= $order['status'] == 'Delivered' ? 'selected' : '' ?>>Delivered</option>
                        <option value="Cancelled" <?= $order['status'] == 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>
                
                <button type="submit" class="btn btn-primary">Add Order</button>
            </form>
            
            <hr>
            
            <h3 class="mt-5">All Orders</h3>
            <?php if (empty($orders)): ?>
                <p>No orders found.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Customer</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($orders as $order): ?>
                                <tr>
                                    <td><?= $order['id'] ?></td>
                                    <td><?= htmlspecialchars($order['firstname'] . ' ' . $order['lastname']) ?></td>
                                    <td><?= htmlspecialchars($order['email']) ?></td>
                                    <td><?= htmlspecialchars($order['phone']) ?></td>
                                    <td>
                                        <span class="badge 
                                            <?= $order['status'] == 'Processing' ? 'badge-secondary' : '' ?>
                                            <?= $order['status'] == 'Confirmed' ? 'badge-info' : '' ?>
                                            <?= $order['status'] == 'Shipping' ? 'badge-primary' : '' ?>
                                            <?= $order['status'] == 'Delivered' ? 'badge-success' : '' ?>
                                            <?= $order['status'] == 'Cancelled' ? 'badge-danger' : '' ?>">
                                            <?= $order['status'] ?>
                                        </span>
                                    </td>
                                    <td><?= date('M d, Y', strtotime($order['created_at'])) ?></td>
                                    <td>
                                        <a href="editorder.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                                        <a href="deleteorder.php?id=<?= $order['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this order?')">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php
require('includes/footer.php');
?>