<?php
require('includes/header.php');
require('../db/conn.php');

$id = $_GET['id'] ?? 0;
$error = '';
$success = '';

// Fetch active categories and brands
$categories = $conn->query("SELECT id, name FROM categories WHERE status = 'Active'")->fetch_all(MYSQLI_ASSOC);
$brands = $conn->query("SELECT id, name FROM brands WHERE status = 'Active'")->fetch_all(MYSQLI_ASSOC);

// Fetch product data
$stmt = $conn->prepare("SELECT * FROM products WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();

if (!$product) {
    die("Product not found");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $product = [
        'id' => $id,
        'name' => trim($_POST['name']),
        'slug' => trim($_POST['slug']),
        'description' => trim($_POST['description']),
        'summary' => trim($_POST['summary']),
        'stock' => (int)$_POST['stock'],
        'price' => (float)$_POST['price'],
        'discounted_price' => (float)$_POST['discounted_price'],
        'category_id' => (int)$_POST['category_id'],
        'brand_id' => (int)$_POST['brand_id']
    ];
    
    if (empty($product['name']) || empty($product['category_id']) || empty($product['brand_id'])) {
        $error = 'Name, category and brand are required';
    } else {
        if (empty($product['slug'])) {
            $product['slug'] = strtolower(str_replace(' ', '-', $product['name']));
        }
        
        $update = $conn->prepare("UPDATE products SET 
            name = ?, slug = ?, description = ?, summary = ?, stock = ?, 
            price = ?, discounted_price = ?, category_id = ?, brand_id = ?, 
            updated_at = NOW() 
            WHERE id = ?");
        $update->bind_param("ssssiddiii", 
            $product['name'], $product['slug'], $product['description'], $product['summary'],
            $product['stock'], $product['price'], $product['discounted_price'],
            $product['category_id'], $product['brand_id'], $product['id']);
        
        if ($update->execute()) {
            $success = 'Product updated successfully!';
            // Refresh product data
            $product = $conn->query("SELECT * FROM products WHERE id = $id")->fetch_assoc();
        } else {
            $error = 'Error updating product: ' . $conn->error;
        }
    }
}
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <h2 class="mb-4">Edit Product</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="name">Product Name</label>
                    <input type="text" class="form-control" id="name" name="name" 
                           value="<?= htmlspecialchars($product['name']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="slug">Slug</label>
                    <input type="text" class="form-control" id="slug" name="slug" 
                           value="<?= htmlspecialchars($product['slug']) ?>">
                </div>
                
                <div class="form-group">
                    <label for="description">Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3"><?= htmlspecialchars($product['description']) ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="summary">Summary</label>
                    <textarea class="form-control" id="summary" name="summary" rows="2"><?= htmlspecialchars($product['summary']) ?></textarea>
                </div>
                
                <div class="form-row">
                    <div class="form-group col-md-4">
                        <label for="stock">Stock</label>
                        <input type="number" class="form-control" id="stock" name="stock" 
                               value="<?= $product['stock'] ?>" min="0" required>
                    </div>
                    
                    <div class="form-group col-md-4">
                        <label for="price">Price</label>
                        <input type="number" step="0.01" class="form-control" id="price" name="price" 
                               value="<?= $product['price'] ?>" min="0" required>
                    </div>
                    
                    <div class="form-group col-md-4">
                        <label for="discounted_price">Discounted Price</label>
                        <input type="number" step="0.01" class="form-control" id="discounted_price" name="discounted_price" 
                               value="<?= $product['discounted_price'] ?>" min="0">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="category_id">Category</label>
                        <select class="form-control" id="category_id" name="category_id" required>
                            <option value="">Select Category</option>
                            <?php foreach ($categories as $category): ?>
                                <option value="<?= $category['id'] ?>" <?= $product['category_id'] == $category['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($category['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group col-md-6">
                        <label for="brand_id">Brand</label>
                        <select class="form-control" id="brand_id" name="brand_id" required>
                            <option value="">Select Brand</option>
                            <?php foreach ($brands as $brand): ?>
                                <option value="<?= $brand['id'] ?>" <?= $product['brand_id'] == $brand['id'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($brand['name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <label>Current Images</label><br>
                    <?php if (!empty($product['images'])): ?>
                        <?php $images = explode(',', $product['images']); ?>
                        <?php foreach ($images as $image): ?>
                            <img src="../uploads/<?= $image ?>" width="100" class="mr-2 mb-2">
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p>No images uploaded</p>
                    <?php endif; ?>
                </div>
                
                <div class="form-group">
                    <label for="images">Update Images</label>
                    <input type="file" class="form-control-file" id="images" name="images[]" multiple>
                </div>
                
                <button type="submit" class="btn btn-primary">Update Product</button>
                <a href="addproduct.php" class="btn btn-secondary">Back to List</a>
            </form>
        </div>
    </div>
</div>
<?php
require('includes/footer.php');
?>