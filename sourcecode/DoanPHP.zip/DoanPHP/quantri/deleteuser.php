<?php
require('../db/conn.php');

$id = $_GET['id'] ?? 0;

if ($id) {
    $stmt = $conn->prepare("UPDATE users SET status = 'Inactive' WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

header("Location: adduser.php");
exit();
?>