<?php
require 'db/conn1.php';
session_start();

header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Not logged in']);
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $product_id = intval($_POST['product_id']);
    $user_id = $_SESSION['user_id'];
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
    
    try {
        // Begin transaction
        $conn->begin_transaction();

        // Check if product exists and is active
        $stmt = $conn->prepare("SELECT id, price, stock FROM products WHERE id = ? AND status = 'Active'");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            throw new Exception("Product not available");
        }
        
        $product = $result->fetch_assoc();
        
        // Check stock availability
        if ($product['stock'] < $quantity) {
            throw new Exception("Not enough stock available");
        }
        
        $price = $product['price'];

        // Get or create pending order
        $stmt = $conn->prepare("SELECT id FROM orders WHERE user_id = ? AND status = 'Pending' FOR UPDATE");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $order = $result->fetch_assoc();
            $order_id = $order['id'];
        } else {
            $stmt = $conn->prepare("INSERT INTO orders (user_id, status) VALUES (?, 'Pending')");
            $stmt->bind_param("i", $user_id);
            if (!$stmt->execute()) {
                throw new Exception("Failed to create order");
            }
            $order_id = $conn->insert_id;
        }

        // Check if product already in cart
        $stmt = $conn->prepare("SELECT id, qty FROM order_details WHERE order_id = ? AND product_id = ? FOR UPDATE");
        $stmt->bind_param("ii", $order_id, $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $item = $result->fetch_assoc();
            $new_qty = $item['qty'] + $quantity;
            
            // Update existing item
            $stmt = $conn->prepare("UPDATE order_details SET qty = ?, price = ? WHERE id = ?");
            $stmt->bind_param("idi", $new_qty, $price, $item['id']);
        } else {
            // Add new item
            $stmt = $conn->prepare("INSERT INTO order_details (order_id, product_id, qty, price) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiid", $order_id, $product_id, $quantity, $price);
        }
        
        if (!$stmt->execute()) {
            throw new Exception("Failed to update cart");
        }

        // Update product stock
        $stmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
        $stmt->bind_param("ii", $quantity, $product_id);
        if (!$stmt->execute()) {
            throw new Exception("Failed to update stock");
        }

        // Commit transaction
        $conn->commit();
        
        // Return success with updated cart count
        $stmt = $conn->prepare("SELECT SUM(qty) as cart_count FROM order_details od JOIN orders o ON od.order_id = o.id WHERE o.user_id = ? AND o.status = 'Pending'");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $cart_count = $result->fetch_assoc()['cart_count'] ?? 0;
        
        echo json_encode(['success' => true, 'cart_count' => $cart_count]);
    } catch (Exception $e) {
        $conn->rollback();
        error_log("Cart error: " . $e->getMessage());
        echo json_encode(['success' => false, 'error' => $e->getMessage()]);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'Invalid request']);
}
?>