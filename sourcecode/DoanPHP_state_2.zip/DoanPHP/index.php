<?php
require('include/header.php');
require('include/sidebar.php');
require('db/conn1.php');

// Function to get all active products
function getAllProducts($conn) {
    $products = [];
    $query = "SELECT p.*, c.name as category_name 
              FROM products p 
              JOIN categories c ON p.category_id = c.id 
              WHERE p.status = 'Active'";
    $result = $conn->query($query);
    
    while ($row = $result->fetch_assoc()) {
        $products[] = $row;
    }
    
    return $products;
}

// Get all products
$products = getAllProducts($conn);
$category_name = "All Products";
?>

<!-- Breadcrumb Section Begin -->
<section class="breadcrumb-section set-bg" data-setbg="img/hero/banner1.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb__text">
                    <h2><?= htmlspecialchars($category_name) ?></h2>
                    <div class="breadcrumb__option">
                        <a href="./index.php">Home</a>
                        <span><?= htmlspecialchars($category_name) ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Breadcrumb Section End -->

<!-- Product Section Begin -->
<section class="product spad">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-5">
                <div class="sidebar">
                    <div class="sidebar__item">
                        <h4>Categories</h4>
                        <ul>
                            <?php 
                            $categoryResult = $conn->query("SELECT * FROM categories WHERE status = 'Active'");
                            if ($categoryResult && $categoryResult->num_rows > 0): 
                            ?>
                                <li><a href="index.php" class="<?= $category_id == 0 ? 'active' : '' ?>">All Products</a></li>
                                <?php while ($category = $categoryResult->fetch_assoc()): ?>
                                    <li>
                                        <a href="products.php?category_id=<?= $category['id'] ?>">
                                            <?= htmlspecialchars($category['name']) ?>
                                        </a>
                                    </li>
                                <?php endwhile; ?>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-9 col-md-7">
                <div class="filter__item">
                    <div class="row">
                        <div class="col-lg-4 col-md-5">
                            <div class="filter__sort">
                                <span>Sort By</span>
                                <select>
                                    <option value="0">Default</option>
                                    <option value="0">Price (High → Low)</option>
                                    <option value="0">Price (Low → High)</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4">
                            <div class="filter__found">
                                <h6><span><?= count($products) ?></span> Products Found</h6>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="row">
                    <?php if (!empty($products)): ?>
                        <?php foreach ($products as $product): 
                            $image_path = 'img/' . $product['images'];
                            if (empty($product['images']) || !file_exists($image_path)) {
                                $image_path = 'img/default-product.jpg';
                            }
                        ?>
                            <div class="col-lg-4 col-md-6 col-sm-6">
                                <div class="product__item">
                                    <div class="product__item__pic set-bg" data-setbg="<?= htmlspecialchars($image_path) ?>">
                                        <ul class="product__item__pic__hover">
                                            <li><a href="#"><i class="fa fa-heart"></i></a></li>
                                            <li><a href="#"><i class="fa fa-retweet"></i></a></li>
                                            <li><a href="quick_checkout.php?product_id=<?= $product['id'] ?>"><i class="fa fa-shopping-cart"></i></a></li>
                                        </ul>
                                    </div>
                                    <div class="product__item__text">
                                        <h6><a href="product-details.php?id=<?= $product['id'] ?>"><?= htmlspecialchars($product['name']) ?></a></h6>
                                        <h5>
                                            <?php if ($product['discounted_price'] > 0): ?>
                                                <?= number_format($product['discounted_price'], 0, ',', '.') ?>₫
                                                <span style="text-decoration: line-through; font-size: 14px; color: #b2b2b2;">
                                                    <?= number_format($product['price'], 0, ',', '.') ?>₫
                                                </span>
                                            <?php else: ?>
                                                <?= number_format($product['price'], 0, ',', '.') ?>₫
                                            <?php endif; ?>
                                        </h5>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="col-lg-12">
                            <div class="alert alert-warning">No products found.</div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- Product Section End -->

<?php
require('include/footer.php');
require('include/script.php');
?>