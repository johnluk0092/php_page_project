<?php
/* 
 * E-Commerce Cart System (All-in-One Version)
 * Save this as cart_system.php
 */

// ==================== CONFIGURATION ====================
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Database Configuration
$db_config = [
    'host' => 'localhost',
    'user' => 'root',
    'pass' => '',
    'name' => 'ecommerce'
];

// ==================== DATABASE CONNECTION ====================
function connect_db() {
    global $db_config;
    $conn = new mysqli(
        $db_config['host'],
        $db_config['user'],
        $db_config['pass'],
        $db_config['name']
    );
    
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
    return $conn;
}

// ==================== CART FUNCTIONS ====================
function add_to_cart($product_id, $user_id, $quantity = 1) {
    $conn = connect_db();
    
    try {
        // 1. Check product exists
        $stmt = $conn->prepare("SELECT id, price FROM products WHERE id=? AND status='Active'");
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $product = $stmt->get_result()->fetch_assoc();
        
        if (!$product) {
            return ['success' => false, 'error' => 'Product not found'];
        }

        // 2. Get or create order
        $stmt = $conn->prepare("SELECT id FROM orders WHERE user_id=? AND status='Pending'");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $order = $stmt->get_result()->fetch_assoc();
        
        $order_id = $order ? $order['id'] : null;
        
        if (!$order_id) {
            $stmt = $conn->prepare("INSERT INTO orders (user_id, status) VALUES (?, 'Pending')");
            $stmt->bind_param("i", $user_id);
            $stmt->execute();
            $order_id = $conn->insert_id;
        }

        // 3. Add/update product in cart
        $stmt = $conn->prepare("SELECT id, qty FROM order_details WHERE order_id=? AND product_id=?");
        $stmt->bind_param("ii", $order_id, $product_id);
        $stmt->execute();
        $item = $stmt->get_result()->fetch_assoc();
        
        if ($item) {
            $new_qty = $item['qty'] + $quantity;
            $stmt = $conn->prepare("UPDATE order_details SET qty=?, price=? WHERE id=?");
            $stmt->bind_param("idi", $new_qty, $product['price'], $item['id']);
        } else {
            $stmt = $conn->prepare("INSERT INTO order_details (order_id, product_id, qty, price) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiid", $order_id, $product_id, $quantity, $product['price']);
        }
        
        $stmt->execute();
        
        return ['success' => true, 'cart_count' => get_cart_count($user_id)];
        
    } catch (Exception $e) {
        return ['success' => false, 'error' => $e->getMessage()];
    }
}

function get_cart_count($user_id) {
    $conn = connect_db();
    $stmt = $conn->prepare("SELECT SUM(qty) as count FROM order_details od 
                           JOIN orders o ON od.order_id=o.id 
                           WHERE o.user_id=? AND o.status='Pending'");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc()['count'] ?? 0;
}

// ==================== REQUEST HANDLER ====================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    header('Content-Type: application/json');
    
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['success' => false, 'error' => 'Not logged in']);
        exit;
    }
    
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add_to_cart':
                if (isset($_POST['product_id'])) {
                    $response = add_to_cart(
                        intval($_POST['product_id']),
                        $_SESSION['user_id'],
                        isset($_POST['quantity']) ? intval($_POST['quantity']) : 1
                    );
                    echo json_encode($response);
                }
                break;
                
            case 'get_cart_count':
                echo json_encode([
                    'success' => true,
                    'count' => get_cart_count($_SESSION['user_id'])
                ]);
                break;
                
            default:
                echo json_encode(['success' => false, 'error' => 'Invalid action']);
        }
    }
    exit;
}

// ==================== HTML INTERFACE ====================
?>
<!DOCTYPE html>
<html>
<head>
    <title>Simple Cart System</title>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .product { border: 1px solid #ddd; padding: 15px; margin: 10px; width: 200px; float: left; }
        .cart-count { background: red; color: white; border-radius: 50%; padding: 2px 6px; }
    </style>
</head>
<body>

<h1>Products</h1>

<!-- Sample Products -->
<div class="product" data-id="1">
    <h3>Product 1</h3>
    <p>$10.00</p>
    <button class="add-cart">Add to Cart</button>
</div>

<div class="product" data-id="2">
    <h3>Product 2</h3>
    <p>$15.00</p>
    <button class="add-cart">Add to Cart</button>
</div>

<!-- Cart Indicator -->
<div style="clear:both; padding-top:20px;">
    <h2>Cart (<span class="cart-count">0</span>)</h2>
</div>

<script>
$(document).ready(function() {
    // Load initial cart count
    updateCartCount();
    
    // Add to cart handler
    $('.add-cart').click(function() {
        const productId = $(this).parent().data('id');
        $.post('cart_system.php', {
            action: 'add_to_cart',
            product_id: productId
        }, function(response) {
            if (response.success) {
                alert('Added to cart!');
                updateCartCount();
            } else {
                alert('Error: ' + response.error);
            }
        }, 'json');
    });
    
    function updateCartCount() {
        $.post('cart_system.php', {
            action: 'get_cart_count'
        }, function(response) {
            if (response.success) {
                $('.cart-count').text(response.count);
            }
        }, 'json');
    }
});
</script>

</body>
</html>