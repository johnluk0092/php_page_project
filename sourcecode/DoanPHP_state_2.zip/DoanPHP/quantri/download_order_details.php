<?php
require_once('../db/conn.php');

// Fetch order details with product and order information
$order_details = $conn->query("
    SELECT od.*, p.name as product_name, o.firstname, o.lastname, o.email, o.status as order_status
    FROM order_details od
    JOIN products p ON od.product_id = p.id
    JOIN orders o ON od.order_id = o.id
    ORDER BY od.created_at DESC
")->fetch_all(MYSQLI_ASSOC);

// Function to generate CSV
function generateOrderDetailsCSV($data) {
    $filename = 'order_details_' . date('Y-m-d') . '.csv';
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    
    $output = fopen('php://output', 'w');
    
    // Header row
    fputcsv($output, array(
        'Order ID', 
        'Product Name', 
        'Price', 
        'Quantity', 
        'Total', 
        'Customer Name',
        'Customer Email',
        'Order Status',
        'Date'
    ));
    
    // Data rows
    foreach ($data as $row) {
        fputcsv($output, array(
            $row['order_id'],
            $row['product_name'],
            $row['price'],
            $row['qty'],
            $row['total'],
            $row['firstname'] . ' ' . $row['lastname'],
            $row['email'],
            $row['order_status'],
            $row['created_at']
        ));
    }
    
    fclose($output);
    exit();
}

// Generate CSV
generateOrderDetailsCSV($order_details);
?>