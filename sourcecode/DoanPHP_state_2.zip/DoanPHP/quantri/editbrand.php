<?php
require('includes/header.php');
require('../db/conn.php');

$id = $_GET['id'] ?? 0;
$error = '';
$success = '';

// Fetch brand data
$stmt = $conn->prepare("SELECT * FROM brands WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$brand = $stmt->get_result()->fetch_assoc();

if (!$brand) {
    die("Brand not found");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $slug = trim($_POST['slug']);
    
    if (empty($name)) {
        $error = 'Brand name is required';
    } else {
        if (empty($slug)) {
            $slug = strtolower(str_replace(' ', '-', $name));
        }
        
        $update = $conn->prepare("UPDATE brands SET name = ?, slug = ?, updated_at = NOW() WHERE id = ?");
        $update->bind_param("ssi", $name, $slug, $id);
        
        if ($update->execute()) {
            $success = 'Brand updated successfully!';
            // Refresh brand data
            $brand = $conn->query("SELECT * FROM brands WHERE id = $id")->fetch_assoc();
        } else {
            $error = 'Error updating brand: ' . $conn->error;
        }
    }
}
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <h2 class="mb-4">Edit Brand</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label for="name">Brand Name</label>
                    <input type="text" class="form-control" id="name" name="name" 
                           value="<?= htmlspecialchars($brand['name']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="slug">Slug</label>
                    <input type="text" class="form-control" id="slug" name="slug" 
                           value="<?= htmlspecialchars($brand['slug']) ?>">
                </div>
                
                <input type="hidden" name="status" value="Active">
                
                <button type="submit" class="btn btn-primary">Update Brand</button>
                <a href="addbrand.php" class="btn btn-secondary">Back to List</a>
            </form>
        </div>
    </div>
</div>
<?php
require('includes/footer.php');
?>