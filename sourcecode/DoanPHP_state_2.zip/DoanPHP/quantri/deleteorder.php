<?php
require('../db/conn.php');

$id = $_GET['id'] ?? 0;

if ($id) {
    // Update order status to 'Cancelled' instead of deleting
    $stmt = $conn->prepare("UPDATE orders SET status = 'Cancelled', updated_at = NOW() WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

header("Location: addorder.php");
exit();
?>