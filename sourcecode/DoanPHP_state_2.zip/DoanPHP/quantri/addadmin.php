<?php
require_once('includes/header.php');
require('../db/conn.php');

// Initialize variables
$name = $email = $phone = $address = $password = '';
$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $address = trim($_POST['address']);
    $password = trim($_POST['password']);
    $type = 'Staff'; // Default to Staff
    
    // Validate inputs
    if (empty($name) || empty($email) || empty($phone) || empty($password)) {
        $error = 'All fields are required except address';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Invalid email format';
    } else {
        // Check if admin exists
        $check = $conn->prepare("SELECT id FROM admins WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();
        
        if ($check->num_rows > 0) {
            $error = 'Admin with this email already exists!';
        } else {
            // Hash password
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Insert new admin (always Active)
            $stmt = $conn->prepare("INSERT INTO admins (name, email, phone, address, password, type, status, created_at) 
                                   VALUES (?, ?, ?, ?, ?, 'Staff', 'Active', NOW())");
            $stmt->bind_param("sssss", $name, $email, $phone, $address, $hashed_password);
            
            if ($stmt->execute()) {
                $success = 'Admin added successfully!';
                // Clear form
                $name = $email = $phone = $address = $password = '';
            } else {
                $error = 'Error adding admin: ' . $conn->error;
            }
        }
    }
}

// Get only active admins
$admins = [];
$result = $conn->query("SELECT id, name, email, phone, type, created_at FROM admins WHERE status = 'Active' ORDER BY created_at DESC");
if ($result && $result->num_rows > 0) {
    $admins = $result->fetch_all(MYSQLI_ASSOC);
}
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <h2 class="mb-4">Add New Admin</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label for="name">Full Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($name) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email" value="<?= htmlspecialchars($email) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone</label>
                    <input type="text" class="form-control" id="phone" name="phone" value="<?= htmlspecialchars($phone) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea class="form-control" id="address" name="address"><?= htmlspecialchars($address) ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                
                <button type="submit" class="btn btn-primary">Add User</button>
            </form>
            
            <hr>
            
            <h3 class="mt-5">Active Admins</h3>
            <?php if (empty($admins)): ?>
                <p>No active admins found.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Type</th>
                                <th>Created At</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($admins as $admin): ?>
                                <tr>
                                    <td><?= $admin['id'] ?></td>
                                    <td><?= htmlspecialchars($admin['name']) ?></td>
                                    <td><?= htmlspecialchars($admin['email']) ?></td>
                                    <td><?= htmlspecialchars($admin['phone']) ?></td>
                                    <td><?= htmlspecialchars($admin['type']) ?></td>
                                    <td><?= date('M d, Y', strtotime($admin['created_at'])) ?></td>
                                    <td>
                                        <a href="editadmin.php?id=<?= $admin['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                                        <a href="deleteadmin.php?id=<?= $admin['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this admin?')">Delete</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php
require_once('includes/footer.php');
?>