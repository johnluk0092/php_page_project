<?php
require('includes/header.php');
require('../db/conn.php');

$id = $_GET['id'] ?? 0;
$error = '';
$success = '';

// Fetch category data
$stmt = $conn->prepare("SELECT * FROM categories WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$category = $stmt->get_result()->fetch_assoc();

if (!$category) {
    die("Category not found");
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $slug = trim($_POST['slug']);
    
    if (empty($name)) {
        $error = 'Category name is required';
    } else {
        if (empty($slug)) {
            $slug = strtolower(str_replace(' ', '-', $name));
        }
        
        $update = $conn->prepare("UPDATE categories SET name = ?, slug = ?, updated_at = NOW() WHERE id = ?");
        $update->bind_param("ssi", $name, $slug, $id);
        
        if ($update->execute()) {
            $success = 'Category updated successfully!';
            // Refresh category data
            $category = $conn->query("SELECT * FROM categories WHERE id = $id")->fetch_assoc();
        } else {
            $error = 'Error updating category: ' . $conn->error;
        }
    }
}
?>
<div class="container mt-5">
    <div class="row">
        <div class="col-md-8 mx-auto">
            <h2 class="mb-4">Edit Category</h2>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= $error ?></div>
            <?php endif; ?>
            
            <?php if ($success): ?>
                <div class="alert alert-success"><?= $success ?></div>
            <?php endif; ?>
            
            <form method="POST">
                <div class="form-group">
                    <label for="name">Category Name</label>
                    <input type="text" class="form-control" id="name" name="name" 
                           value="<?= htmlspecialchars($category['name']) ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="slug">Slug</label>
                    <input type="text" class="form-control" id="slug" name="slug" 
                           value="<?= htmlspecialchars($category['slug']) ?>">
                </div>
                
                <input type="hidden" name="status" value="Active">
                
                <button type="submit" class="btn btn-primary">Update Category</button>
                <a href="addcategory.php" class="btn btn-secondary">Back to List</a>
            </form>
        </div>
    </div>
</div>
<?php
require('includes/footer.php');
?>