<?php
require('../db/conn1.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    
    // Get user's pending order
    $stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? AND status = 'Pending'");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $order = $result->fetch_assoc();
    
    if (!$order) {
        header("Location: cart.php");
        exit();
    }
    
    $order_id = $order['id'];
    
    // Process payment (dummy implementation)
    $card_number = str_replace(' ', '', $_POST['card_number']);
    $exp_date = $_POST['exp_date'];
    $cvv = $_POST['cvv'];
    
    // For demo purposes, we'll just validate the dummy card
    if ($card_number === '4242424242424242' && preg_match('/^\d{2}\/\d{2}$/', $exp_date) && preg_match('/^\d{3}$/', $cvv)) {
        // Payment successful - update order
        $stmt = $conn->prepare("UPDATE orders SET 
                              status = 'Processing',
                              fullname = ?,
                              address = ?,
                              phone = ?,
                              email = ?,
                              payment_method = 'Credit Card',
                              updated_at = NOW()
                              WHERE id = ?");
        $stmt->bind_param("ssssi", 
            $_POST['fullname'],
            $_POST['address'],
            $_POST['phone'],
            $_POST['email'],
            $order_id
        );
        $stmt->execute();
        
        // Redirect to thank you page
        header("Location: thank-you.php?order_id=" . $order_id);
        exit();
    } else {
        // Payment failed
        header("Location: checkout.php?error=payment");
        exit();
    }
}

header("Location: checkout.php");
exit();
?>